import java.util.ArrayList;

public class Historico {

    private final ArrayList<String> operacoes = new ArrayList<>();

    public void adicionar(
            double num1,
            String simbolo,
            double num2,
            double resultado
    ) {
        operacoes.add(
                num1 + " " + simbolo + " " + num2 + " = " + resultado
        );
    }

    public void exibir() {

        IO.println("Histórico:");

        if (operacoes.isEmpty()) {
            IO.println("Nenhuma operação foi realizada.");
            return;
        }

        for (var operacao : operacoes) {
            IO.println(operacao);
        }
    }
}