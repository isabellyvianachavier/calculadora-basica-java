import java.util.HashMap;
import java.util.Map;

void main() {

    var historico = new Historico();

    var operacoes = new HashMap<String, Operacao>();

    for (var operacao : Operacao.values()) {
        operacoes.put(operacao.getSimbolo(), operacao);
    }

    while (true) {
        // Forma visual da calculadora no terminal
        IO.println("""
                
                ======================================
                       CALCULADORA ATUALIZADA
                ======================================
                 Olá! Antes de mexer na calculadora, 
                preciso que você escolha uma das três
                opções abaixo:
                
                Digite .exit para sair.
                Digite -h para ver o histórico.
                Pressione ENTER para continuar.
                
                """);

        var comando = IO.readln();

        // Opção para sair
        if (comando.equals(".exit")) {
            IO.println("Calculadora encerrada.");
            break;
        }

        // Opção histórico
        if (comando.equals("-h")) {
            historico.exibir();
            continue;
        }

        // Apenas a tecla ENTER inicia uma operação
        if (!comando.isEmpty()) {
            IO.println("Comando inválido.");
            continue;
        }

        try {

            IO.println("Digite o primeiro número:");
            var num1 = Double.parseDouble(IO.readln());

            IO.println("Digite o segundo número:");
            var num2 = Double.parseDouble(IO.readln());

            IO.println("""
                    
                    Digite a operação desejada:
                    
                    +    | Soma
                    -    | Subtração
                    *    | Multiplicação
                    /    | Divisão
                    pow  | Potenciação
                    %    | Resto da divisão
                    max  | Maior valor
                    min  | Menor valor
                    
                    """);

            var simbolo = IO.readln();

            // Procura a operação
            var operacao = operacoes.get(simbolo);

            // Se digitou a operação errada, algo fora do que pedido, exeuta:
            if (operacao == null) {
                IO.println("Operação inválida.");
                continue;
            }

            // Executa
            var resultado = operacao.executar(num1, num2);

            IO.println("Resultado: " + resultado);

            // Salva no histórico
            historico.adicionar(
                    num1,
                    simbolo,
                    num2,
                    resultado
            );

        } catch (NumberFormatException e) {

            IO.println("Digite números válidos.");

        } catch (ArithmeticException e) {

            IO.println(e.getMessage());
        }
    }
}