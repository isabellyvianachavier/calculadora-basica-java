import java.util.function.BiFunction;

    public enum Operacao {

    SOMA("+", (a, b) -> a + b),

    SUBTRACAO("-", (a, b) -> a - b),

    MULTIPLICACAO("*", (a, b) -> a * b),

    DIVISAO("/", (a, b) -> {
        if (b == 0) {
            throw new ArithmeticException("Divisão por zero é inválida.");
        }

        return a / b;
    }),

    POTENCIACAO("pow", Math::pow),

    RESTO("%", (a, b) -> a % b),

    MINIMO("min", Math::min),

    MAXIMO("max", Math::max);


    private final String simbolo;
    private final BiFunction<Double, Double, Double> calculo;

    Operacao(
            String simbolo,
            BiFunction<Double, Double, Double> calculo
    ) {
        this.simbolo = simbolo;
        this.calculo = calculo;
    }

    public String getSimbolo() {
        return simbolo;
    }

    public double executar(double num1, double num2) {
        return calculo.apply(num1, num2);
    }
}